package ua.valeriishymchuk.utils.stream.model;

public interface CheckedRunnable {

    void run() throws Throwable;

}
